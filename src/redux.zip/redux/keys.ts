export enum EntityKeys {
    AUTH = 'auth',
    APP = 'app',
  }
  