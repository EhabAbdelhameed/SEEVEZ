export const headers: any = {
    'Content-Type': 'multipart/form-data',
    Accept: 'application/json',
};

