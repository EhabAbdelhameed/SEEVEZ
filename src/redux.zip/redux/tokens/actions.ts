import {createAction} from '@reduxjs/toolkit';

export const doSetToken = createAction<any>('set_checkup');
